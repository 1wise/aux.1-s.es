# Timestamp: 2026-11-23 | Version: 8.0.1-beta.5
# Author & Credits: https://www.alawise.es/1-s
"""Interactive menu/dialog bridge and manifest validation for AUX installers.

Ensures that imported JSON selection manifests are strictly treated as passive
data (never granting implicit execution or arbitrary shell flags) and maps
arbitrary Python objects to stable string IDs for curses/TTY menus.
"""
import json
from pathlib import Path
import shutil
import subprocess
import sys

from . import VERSION
from .profiles import ROLES, DEFAULT_ROLES, ROTULOS, seleccion
from . import software
from .console_ui import aplicacion, campo, selecciona


def lee_seleccion(pth):
    """Validate an exported JSON selection manifest without permitting code execution."""
    if pth.stat().st_size > 131072:
        raise ValueError('Selección demasiado grande.')
    dat = json.loads(pth.read_text())
    campos = {'schema', 'distribution', 'roles', 'native', 'mode', 'root', 'iso', 'iso_sha256', 'output', 'release', 'identity','target_mode'}
    if not isinstance(dat, dict) or set(dat) - campos or dat.get('schema') != 'aux-install-v1':
        raise ValueError('Selección AUX inválida: no admite permisos, comandos ni opciones adicionales.')
    if dat.get('mode') not in ('existing', 'root', 'iso','kernel-modeler'):
        raise ValueError('Modo de instalación inválido.')
    if not isinstance(dat.get('roles'), list) or any(not isinstance(val, str) for val in dat['roles']):
        raise ValueError('La selección debe declarar una lista de perfiles.')
    if dat['mode']=='kernel-modeler' and dat.get('target_mode') not in ('iso','root','existing'):raise ValueError('Kernel Modeler requiere target_mode explícito.')
    roles=dat['roles']+(['kernel-modeler'] if dat['mode']=='kernel-modeler' else [])
    sel = seleccion(dat.get('distribution'), roles, dat.get('native'))
    for nom in ('root', 'iso', 'iso_sha256', 'output', 'release'):
        if nom in dat and (not isinstance(dat[nom], str) or len(dat[nom]) > 4096 or any(ord(car) < 32 for car in dat[nom])):
            raise ValueError('Campo inválido en selección: ' + nom)
    sal = {'distro': dat['distribution'], 'mode': dat['mode'], 'roles': ','.join(sel['roles'])}
    if dat['mode']=='kernel-modeler':sal['target_mode']=dat['target_mode']
    if 'native' in sel:
        sal['native'] = sel['native']
    for nom in ('root', 'iso', 'iso_sha256', 'output', 'release'):
        if nom in dat:
            sal[nom] = dat[nom]
    if 'identity' in dat:
        from .identity import normaliza
        sal['identity']=normaliza(dat['identity'])
    return sal


def elige(rot, opciones, defecto=1, detalles=None):
    """Present a single-choice menu; map complex option values to stable index IDs."""
    if not opciones:
        raise ValueError('No hay opciones disponibles.')
    if not isinstance(defecto, int) or not 1 <= defecto <= len(opciones):
        raise ValueError('Opción predeterminada fuera de rango.')
    if detalles is not None and len(detalles) != len(opciones):
        raise ValueError('Los detalles deben corresponder a las opciones.')
    if sys.stdin.isatty() and sys.stdout.isatty():
        # Curses widgets operate on string keys; keep the underlying dicts/booleans/lists
        # indexed in `valores` so callers get their exact Python object back.
        valores = {str(idx): val for idx, (_, val) in enumerate(opciones)}
        extra = {'detalles': {str(idx): v for idx, v in enumerate(detalles)}} if detalles is not None else {}
        elegido = selecciona(
            rot,
            [(str(idx), nom) for idx, (nom, _) in enumerate(opciones)],
            [str(defecto - 1)],
            **extra,
        )
        if not isinstance(elegido, str) or elegido not in valores:
            raise ValueError('Selección de menú inválida.')
        return valores[elegido]

    # Non-interactive / dumb TTY fallback using numbered lines.
    print('\n' + rot)
    for idx, (nom, _) in enumerate(opciones, 1):
        print(f'  {idx}. {nom}')
        if detalles is not None:
            for lin in detalles[idx - 1]:
                print('     ' + lin)
    while True:
        txt = input(f'Opcion [{defecto}; 0 cancela; ? ayuda]: ').strip() or str(defecto)
        if txt == '0':
            raise KeyboardInterrupt
        if txt == '?':
            from .helptext import ayuda
            print('\n'.join(ayuda(rot)))
            continue
        if txt.isdigit() and 1 <= int(txt) <= len(opciones):
            return opciones[int(txt) - 1][1]
        print('Opción fuera de rango. Se conserva el menú.')


def marca(rot, opciones, elegidos=(), categorias=None):
    """Present a multi-choice checkbox selector with category grouping and TTY fallback."""
    ids = [nom for nom, _ in opciones]
    act = set(elegidos)
    if sys.stdin.isatty() and sys.stdout.isatty():
        return selecciona(rot, opciones, elegidos, multiple=True, categorias=categorias)

    # Searchable plain-text fallback when curses is unavailable.
    bus = ''
    while True:
        print('\n' + rot + ' | ' + str(len(act)) + ' seleccionados')
        for idx, (nom, des) in enumerate(opciones, 1):
            if (bus and bus.lower() in (nom + ' ' + des).lower()) or (not bus and (len(opciones) < 40 or nom in act)):
                print(f'  {idx:3}. [{"x" if nom in act else " "}] {des} ({nom})')
        txt = input('Números para alternar; ?texto busca todos; Enter acepta; 0 cancela: ').strip()
        if not txt:
            return [nom for nom in ids if nom in act]
        if txt == '0':
            raise KeyboardInterrupt
        if txt.startswith('?'):
            bus = txt[1:]
            continue
        vals = [val.strip() for val in txt.split(',')]
        if any(not val.isdigit() or not 1 <= int(val) <= len(ids) for val in vals):
            print('Casilla fuera de rango. Se conserva toda la selección.')
            continue
        for val in vals:
            nom = ids[int(val) - 1]
            if nom in act:
                act.remove(nom)
            else:
                act.add(nom)


def software_nativo(dis,kernel=False):
    """Walk the operator through Fedora comps environments/groups or Debian tasksel tasks."""
    dat = software.carga(dis)
    nat = software.minimo(dis) if kernel else software.defecto(dis)
    lista = dat['groups']
    if dis == 'fedora':
        nat['environment'] = elige(
            'Entorno base de Fedora',
            [('Solo grupos', '')] + [(ent['label'], ent['id']) for ent in dat['environments']],
            1 + next((idx for idx, ent in enumerate(dat['environments'], 1) if ent['id'] == nat['environment']),0),
        )
        ent = next((ent for ent in dat['environments'] if ent['id'] == nat['environment']), None)
        req = ent['required'] if ent else []
        categorias = {}
        for entorno in dat['environments']:
            for grupo in entorno['required'] + entorno['default']:
                categorias.setdefault(grupo, entorno['label'])
        categorias.update({g['id']: categorias.get(g['id'], 'Otros grupos') for g in lista})
        nat['groups'] = marca(
            'Complementos y grupos nativos de Fedora',
            [(ent['id'], ent['label']) for ent in lista if ent['id'] not in req],
            ent['default'] if ent else [],
            categorias=categorias,
        )
        print('Grupos requeridos por el entorno:', ', '.join(req) or 'ninguno')
    elif dis == 'alpine':
        nat['groups'] = marca('Colecciones AUX para Alpine · paquetes apk',
            [(ent['id'], ent['label']) for ent in lista], nat['groups'])
    else:
        mapa_sec = {'l10n': 'Idiomas', 'server': 'Servicios', 'user': 'Escritorios y sistema'}
        nat['tasks'] = marca(
            'Tareas nativas de Debian: escritorios, servicios e idiomas',
            [(ent['id'], ent['label']) for ent in lista],
            nat['tasks'],
            categorias={ent['id']: mapa_sec.get(ent.get('section'), 'Otras tareas') for ent in lista},
        )
    return software.resuelve(dis, nat)['native']


@aplicacion('AUX SETUP', 'ejecucion')
def prepara(cfg):
    """Interactive setup wizard: keeps ISO/root builders first and host mutation last."""
    print('AUX ' + VERSION + ' | INSTALAR Y PERSONALIZAR')
    modos = [
        ('Preparar un instalador ISO', 'iso'),
        ('Preparar una base nueva en un directorio vacío', 'root'),
        ('Kernel Modeler: preparar banco de trabajo de núcleos', 'kernel-modeler'),
        ('Portal AUX / TEC / gateway: instala servicios en este equipo', 'server'),
        ('Solo herramientas AUX: instala archivos en el destino indicado', 'tools'),
        ('Instalar SOBRE EL SISTEMA ACTUAL: modifica este equipo', 'existing'),
    ]
    if not getattr(cfg, 'mode', None):
        cfg.mode = elige('Destino de la instalación', modos)
    if cfg.mode=='kernel-modeler':
        cfg.target_mode=getattr(cfg,'target_mode',None) or elige('Kernel Modeler · destino explícito',[('Preparar instalador ISO','iso'),('Raíz nueva','root'),('SISTEMA ACTUAL · instala paquetes en este equipo','existing')])
        cfg.workbench='kernel-modeler';cfg.mode=cfg.target_mode
    if cfg.mode == 'existing':
        cfg.root = Path('/')
        print('\nDESTINO: SISTEMA ACTUAL. Se modificarán paquetes, aplicaciones y configuración de este equipo.')
    if cfg.mode in ('existing', 'root', 'iso'):
        cfg.distro = elige('Distribución', [('Debian Testing', 'debian'), ('Fedora Rawhide', 'fedora'), ('Alpine edge', 'alpine')])
        cfg.native = software_nativo(cfg.distro,kernel=getattr(cfg,'workbench',None)=='kernel-modeler')
    if cfg.mode in ('existing', 'root', 'iso', 'tools'):
        lista = [nom for nom in ROLES if nom not in ('base', 'desktop')]
        defaults=['kernel-modeler'] if getattr(cfg,'workbench',None)=='kernel-modeler' else [nom for nom in lista if nom in DEFAULT_ROLES]
        chosen=marca('Herramientas adicionales AUX', [(nom, ROTULOS[nom]) for nom in lista], defaults)
        if getattr(cfg,'workbench',None)=='kernel-modeler' and 'kernel-modeler' not in chosen:chosen.append('kernel-modeler')
        cfg.roles=','.join(['base']+chosen)
        dat = seleccion(cfg.distro, cfg.roles.split(','), getattr(cfg, 'native', None))
        print('\nSelección:', ', '.join(dat['roles']), '|', len(dat['packages']), 'paquetes/grupos')
    if cfg.mode == 'root':
        cfg.root = Path(campo('Raíz nueva absoluta', '/mnt/aux-root'))
    elif cfg.mode == 'iso':
        cfg.iso = Path(campo('ISO oficial de entrada'))
        cfg.iso_sha256 = campo('SHA-256 del medio comprobado')
        cfg.output = Path(campo('ISO nueva de salida'))
        cfg.check_packages = True
    elif cfg.mode == 'server':
        cfg.root = Path(campo('Directorio del proyecto', '/var/www/aux.1-s.es'))
        cfg.nginx = campo('Instalar los vhosts revisados [s/N]').lower() == 's'
    if cfg.mode in ('existing','root','iso'):
        from .identity import pregunta
        cfg=pregunta(cfg)
    cfg.apply = False
    return cfg
