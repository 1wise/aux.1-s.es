# AUX Rescue Fedora 44 — ISO compilada, 5.0.1-dev.5

2026-10-14 · Concepto y créditos: https://www.alawise.es/1-s

ISO x86_64 híbrida BIOS/UEFI: **467,1 MiB** (489.816.064 bytes).
SHA-256: `89516a77e73c40b3b3dd5392e940a658da5732904c11dad2291127e6b15f2383`.
Kernel 7.2.9-201.fc44.x86_64. 94 solicitudes, 382 RPM resueltos y una entrada GPG
adicional en el inventario. La lista real completa está adjunta.

## Verificación realizada

- Arranque limpio BIOS y UEFI/OVMF en QEMU, 4 GiB de RAM y sin discos de cliente.
- Arranque del mismo Rootfs por HTTP con los argumentos Live de iPXE.
- SSH cerrado antes de AUTORIZO; clave distinta rechazada.
- Sesión root /bin/bash funcional con SELinux Enforcing.
- Cerrar con Enter detiene la escucha y termina las terminales del técnico.
- Intentos de crear archivos desde F7 y F8 no ejecutan comandos.
- /work es tmpfs 0700, nosuid,nodev; permite ejecutar herramientas.
- Dnf instaló tree-2.2.1-4.fc44 con comprobación de firma, en el overlay Live.

Medición en una VM de 4096 MiB: MemTotal 3900 MiB, usados 406 MiB,
disponibles 3493 MiB; /work limitó a 976 MiB. El límite no reserva esa memoria.
El arranque HTTP guarda además el Rootfs descargado en RAM. No hay swap.

No se ha probado Cari, sus adaptadores Wi-Fi ni Secure Boot. La ISO contiene
NetworkManager-wifi, wpa_supplicant y linux-firmware. La prueba de dnf utilizó
un RPM oficial verificado servido por HTTP local: la red de esta VM bloquea
el acceso directo a los mirrors públicos. Se conservan los repositorios Fedora.

## Uso

Ctrl-Alt-F6: elegir técnico, configurar red, autorizar y cerrar. Ctrl-Alt-F7:
intervención en solo lectura. Ctrl-Alt-F8: estado y RAM. El teclado de control
permanece activo. Puerto SSH 2222 solo después de AUTORIZO. Introducir la
clave pública del técnico, nunca su clave privada. Se requiere ruta directa
por intranet o una VPN configurada; esta edición no crea peers de WireGuard.

No hay contraseña root compartida ni técnicos privados incorporados. El Live
y /work se pierden al reiniciar. El técnico autorizado tiene privilegios root.

GRUB: arranque Live inicial, cinco segundos, texto verde sobre negro y selección
azul sobre cian; entrada al firmware UEFI. La comprobación automática de medio
no se ofrece en el menú del runtime mínimo; verificar el SHA-256 adjunto.

## Desplegar en Excalibur

Guardar la ISO en /var/www/aux.1-s.es/isos y comprobar su SHA antes de desplegar.
Desde el proyecto AUX/PXE actualizado, fases independientes:

```bash
sha256sum -c aux-rescue-5.0.1-dev.5-x86_64.iso.sha256
sudo install -o root -g nginx -m 0644 aux-rescue-5.0.1-dev.5-x86_64.iso /var/www/aux.1-s.es/isos/
sudo bash deploy.sh ram --only aux-rescue-5.0.1-dev.5 --verbose
sudo bash generate.sh --verbose
```

Generate reconocerá aux.assist/rd.live.image en la configuración real del medio.
La entrada de asistencia corresponde al capítulo 0; el menú vigente elige la
última imagen completa compatible tras 60 segundos. Conservar la ISO 0.1.0
hasta comprobar el arranque en Cari. El servidor debe servir kernel/initrd y
LiveOS/squashfs.img por HTTP. Publicar la ISO completa en Bastion con deploy FTP
como fase independiente, según fast-boot.json.

## Recompilar en Fedora 44

Partir de las fuentes tec-fedora44-rescue-5.0.1-dev.5-sources del proyecto.
Aplicar assist-selinux.patch en la raíz de esas fuentes: añade la unidad SSH
independiente, conserva SELinux y evita el initramfs duplicado dentro del Rootfs.

```bash
sudo dnf install lorax lorax-lmc-virt pykickstart openssl xorriso squashfs-tools
patch -p1 < assist-selinux.patch
python3 test_sources.py
python3 prepare.py --output work-5.0.1-dev.5
ksvalidator -v F44 work-5.0.1-dev.5/assist.ks
sudo livemedia-creator \
  --make-iso --iso=/ruta/Fedora-Server-netinst-x86_64-44-1.7.iso \
  --ks="$PWD/work-5.0.1-dev.5/assist.ks" --releasever=44 \
  --project="1-s AUX Rescue" --volid=AUX_RESCUE_501 \
  --rootfs-type=squashfs --dracut-conf="$PWD/dracut.conf" \
  --extra-boot-args="aux.assist rd.live.overlay.overlayfs=1 rd.luks=0 rd.lvm=0 rd.md=0" \
  --ram=4096 --vcpus=2 --iso-only \
  --iso-name=aux-rescue-5.0.1-dev.5-x86_64.iso \
  --resultdir="$PWD/results-5.0.1-dev.5" \
  --logfile="$PWD/compile-5.0.1-dev.5.log"
```

Verificar el netinst oficial con su CHECKSUM firmado. La receta contiene
clearpart para el disco virtual de construcción. El resultado normal de Lorax
conserva su configuración de GRUB: para obtener el menú de esta entrega ajustar
sus configuraciones a default=0, timeout=5 y los colores indicados; normalizar
solo los archivos externos del ISO a 0644 y directorios a 0755, reproducir los
registros de arranque con xorriso y recalcular SHA-256.

Esta compilación se instaló con Lorax/Anaconda dentro de una VM desechable,
con repositorios oficiales a través de un relay local y comprobaciones de las
fuentes. Squashfs-tools 4.7.5 comprimió fuera de la emulación conservando IDs,
permisos, enlaces y etiquetas SELinux. El empaquetado final utilizó los archivos
BIOS/UEFI generados por Lorax. Se retiró el initramfs generado redundante de
/boot dentro del Rootfs; el initramfs Live externo se conserva. Las tres fuentes
de asistencia corregidas se comprobaron contra el Rootfs de la ISO final.

Las actualizaciones de Fedora no están fijadas a un snapshot; este comando no
promete reproducibilidad bit a bit. El parche debe mantenerse junto a las fuentes
originales para conservar la corrección de SSH. Los scripts download/deploy/generate
no forman parte de la ISO y siguen siendo fases independientes.

Los paquetes conservan sus licencias respectivas. Los contenidos y el concepto
corresponden a los créditos y a la licencia del proyecto; no se asigna CC BY-NC-SA
a los binarios de terceros.
