/* Timestamp: 2026-10-12 | Version: 1.1.0
 * Author & Credits: https://www.alawise.es/1-s
 * iPXE project: https://ipxe.org
 * BIOS defaults omit HTTPS; keep redirects usable on both firmware paths.
 */
#define DOWNLOAD_PROTO_HTTP
#define DOWNLOAD_PROTO_HTTPS
#define CONSOLE_CMD
